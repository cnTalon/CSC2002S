package MonteCarloMini;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import MonteCarloMini.SearchParallel.SearchMin;

class MonteCarloMinimizationParallel{
	static final boolean DEBUG=false;
	static long startTime = 0;
	static long endTime = 0;

	//timers - note milliseconds
	private static void tick(){
		startTime = System.currentTimeMillis();
	}
	private static void tock(){
		endTime=System.currentTimeMillis(); 
	}
	
    public static void main(String[] args)  {
    	int rows, columns; //grid size
    	double xmin, xmax, ymin, ymax; //x and y terrain limits
    	TerrainArea terrain;  //object to store the heights and grid points visited by searches
    	double searchDensity;	// Density - number of Monte Carlo  searches per grid position - usually less than 1!
     	int numSearches;		// Number of searches
    	SearchParallel [] searches;		// Array of searches
    	Random rand = new Random();  //the random number generator
    	
    	/* Read argument values */
    	rows =Integer.parseInt(args[0] );
    	columns = Integer.parseInt(args[1] );
    	xmin = Double.parseDouble(args[2]);
    	xmax = Double.parseDouble(args[3] );
    	ymin = Double.parseDouble(args[4]);
    	ymax = Double.parseDouble(args[5] );
    	searchDensity = Double.parseDouble(args[6] );;
  
    	if(DEBUG) {
    		/* Print arguments */
    		System.out.printf("Arguments, Rows: %d, Columns: %d\n", rows, columns);
    		System.out.printf("Arguments, x_range: ( %f, %f ), y_range( %f, %f )\n", xmin, xmax, ymin, ymax );
    		System.out.printf("Arguments, searches_density: %f\n", searchDensity );
    		System.out.printf("\n");
    	}
    	// Initialize 
    	terrain = new TerrainArea(rows, columns, xmin,xmax,ymin,ymax);
    	numSearches = (int)( rows * columns * searchDensity );
    	searches= new SearchParallel [numSearches];
		// new fork join pool
		ForkJoinPool fj = new ForkJoinPool();
		SearchMin actions = new SearchMin(searches, 0, numSearches);
    	
		for (int i = 0; i < numSearches; i++) 
    		searches[i]=new SearchParallel(i + 1, rand.nextInt(rows), rand.nextInt(columns), terrain);
    	
      	if (DEBUG) {
    		/* Print initial values */
    		System.out.printf("Number searches: %d\n", numSearches);
    		//terrain.print_heights();
    	}
    	//start timer
    	tick();
    	//all searches using fork/join pool returns globalMin as an integer
        int globalMin = fj.invoke(actions);
   		//end timer
   		tock();
   		
    	if(DEBUG) {
    		/* print final state */
    		terrain.print_heights();
    		terrain.print_visited();
    	}
    	
		System.out.printf("Run parameters\n");
		System.out.printf("\t Rows: %d, Columns: %d\n", rows, columns);
		System.out.printf("\t x: [%f, %f], y: [%f, %f]\n", xmin, xmax, ymin, ymax );
		System.out.printf("\t Search density: %f (%d searches)\n", searchDensity,numSearches );

		/*  Total computation time */
		System.out.printf("Time: %d ms\n", endTime - startTime );
		int tmp = terrain.getGrid_points_visited();
		System.out.printf("Grid points visited: %d  (%2.0f%s)\n", tmp, (tmp/(rows*columns*1.0)) * 100.0, "%");
		tmp = terrain.getGrid_points_evaluated();
		System.out.printf("Grid points evaluated: %d  (%2.0f%s)\n", tmp, (tmp/(rows*columns*1.0)) * 100.0, "%");
	
		/* Results*/
		System.out.printf("Global minimum: %d at x=%.1f y=%.1f\n\n", globalMin, terrain.getXcoord(searches[actions.getFinder()].getPos_row()), terrain.getYcoord(searches[actions.getFinder()].getPos_col()) );
	}
}