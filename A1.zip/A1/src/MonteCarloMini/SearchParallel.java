package MonteCarloMini;
import java.util.concurrent.RecursiveTask;

/* Adapted from M. Kuttel 2023
 * Searcher class that lands somewhere random on the surfaces and 
 * then moves downhill, stopping at the local minimum.
 */

public class SearchParallel {
	private int id;				// Searcher identifier
	private int pos_row, pos_col;		// Position in the grid
	private int steps; //number of steps to end of search
	private boolean stopped;			// Did the search hit a previous trail?
	private TerrainArea terrain;

	enum Direction {
		STAY_HERE,
	    LEFT,
	    RIGHT,
	    UP,
	    DOWN
	  }

	public SearchParallel(int id, int pos_row, int pos_col, TerrainArea terrain) {
		this.id = id;
		this.pos_row = pos_row; //randomly allocated
		this.pos_col = pos_col; //randomly allocated
		this.terrain = terrain;
		this.stopped = false;
	}
	
	public int find_valleys() {	
		int height = Integer.MAX_VALUE;
		Direction next = Direction.STAY_HERE;
		while (terrain.visited(pos_row, pos_col) == 0) { // stop when hit existing path
			height = terrain.get_height(pos_row, pos_col);
			terrain.mark_visited(pos_row, pos_col, id); //mark current position as visited
			steps++;
			next = terrain.next_step(pos_row, pos_col);
			switch (next) {
				case STAY_HERE: return height; //found local valley
				case LEFT: 
					pos_row--;
					break;
				case RIGHT:
					pos_row = pos_row + 1;
					break;
				case UP: 
					pos_col = pos_col - 1;
					break;
				case DOWN: 
					pos_col = pos_col + 1;
					break;
			}
		}
		stopped = true;
		return height;
	}

	// adapted from lecture slides to find the minimum value
    static class SearchMin extends RecursiveTask<Integer> {
		int low;
		int high;
		SearchParallel[] numSearch;
		static final int SEQUENTIAL_CUTOFF = 1000;
		static int min = 0;
		static int finder = -1;
		static final boolean DEBUG = false;
		// for use with the monte carlo output for global minimum
		public int getFinder() {
			return finder;
		}

		SearchMin(SearchParallel[] n, int i, int h) {
			low = i;
			high = h;
			numSearch = n;
		}
		// replaced the for loop with the for loop inside the serial programs search and use it as a compute task
        protected Integer compute() {
			if ((high-low) < SEQUENTIAL_CUTOFF) {
				int min = Integer.MAX_VALUE;
				int localMin = Integer.MAX_VALUE;
				for  (int i = low; i < high; i++) {
						localMin = numSearch[i].find_valleys();
						if ((!numSearch[i].isStopped()) && (localMin<min)) { //don't look at  those who stopped because hit exisiting path
							min = localMin;
							finder = i; //keep track of who found it
						}
						if (DEBUG) System.out.println("Search " + numSearch[i].getID() + " finished at  " + localMin + " in " + numSearch[i].getSteps());
					}
                return min;
			}
			else {
				SearchMin left = new SearchMin(numSearch, low, (high + low)/2);
				SearchMin right = new SearchMin(numSearch, (high + low)/2, high);
				left.fork();
				int rightAns = right.compute();
				int leftAns = left.join();
				return Math.min(leftAns, rightAns);
			}
		}
	}

	public int getID() {
		return id;
	}

	public int getPos_row() {
		return pos_row;
	}

	public int getPos_col() {
		return pos_col;
	}

	public int getSteps() {
		return steps;
	}
	public boolean isStopped() {
		return stopped;
	}
}