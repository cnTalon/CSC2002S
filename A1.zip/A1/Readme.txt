To run the parallel program in Unix:
1. Open the Linux terminal
2. Find the Program file
3. Type 'make' and let it compile
4. Type 'make run ARGS="rows cols xmin xmax ymin ymax search_density"
5. Hit 'Enter'

To the the parallel program on a Windows machine on VSCode:
1. Open a new terminal
2. Type in 'java -cp bin MonteCarloMini.MonteCarloMinimizationParallel rows cols xmin xmax ymin ymax search_density'
3. Hit 'Enter'