Please note:
-Only the image files usable with the programs have been included in the .zip compression
-The .zip compression should include the following 10 files/folders: greyscale.asm, increase_brightness.asm, house_64_in_ascii_lf.ppm, jet_64_in_ascii_lf.ppm, tree_64_in_ascii_lf.ppm, question1.ppm, question2.ppm, sample_images.zip, .git and this README.md

PROGRAMS WERE CODED WITH THE FOLLOWING IN MIND:
1. The input image provided will always be 64x64 pixels in size
2. The input image provided will always have the header in the form provided in the instruction document
3. The RGB values are always between [0, 255] and are not padded
4. The programs will be run in QTSPIM

How to use:
!!MAKE SURE IMAGE FILES ARE IN SAME DIRECTORY AS THE .ASM FILE FOR EASE OF USE!!
Question 1 (increase_brightness.asm):
1. The program was coded and tested using the .ppm files with the LF tag on a Windows System
2. Hard code the absolute paths of the input image and the output file into the input (line 6) and output (line 10) data variables (the included file is called question1.ppm for this question)
3. Open QTSpim and select 'Reinitialise and Load File'
4. Select increase_brightness.asm and press the green play button
5. Once the program finishes running, the averages should be displayed to console
6. View output file in GIMP to check correctness
7. Be sure to clear question1.ppm manually after every run 
8. Program is programmed to recognise newline character of ascii value 10

Question 2 (greyscale.asm):
1. The program was coded and tested using the .ppm files with the LF tag on a Windows System 
2. Hard code the absolute paths of the input image and the output file into the input (line 6) and output (line 8) data variables (the included file is called question2.ppm for this question)
3. Open QTSpim and select 'Reinitialise and Load File'
4. Select greyscale.asm and press the green play button
5. Once the program finishes running, nothing will be displayed to console
6. View output file in GIMP to check correctness
7. Be sure to clear question2.ppm manually after every run
8. Program is programmed to recognise newline character of ascii value 10

Side notes:
-Q1 logic: read in file, save header (first 4 lines), loop convert pixels from string to integer, add 10 to increase brightness (or set to 255 if already 255 or will go over 255), convert back to string, reverse string so it in correct, count the total bytes inside an output string and use it to write into a file
-Q2 logic: read in file, save header (convert P3 to P2), loop convert pixels from string to integer, add RGB pixels together, find average, convert average from integer to string, reverse the string, count total bytes inside output string and use it to write into file
