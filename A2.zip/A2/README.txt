To run the clubSimulation in Unix:
1. Open the Linux terminal
2. Find the Program folder
3. Type 'make' and let it compile
4. Type 'make run ARGS="noClubgoers numxGridCells numyGridCells clubLimit" to run a custom sim or 'make run' to run default
5. Hit 'Enter'

To the the clubSimulation on a Windows machine on VSCode:
1. Open a new terminal on the folder
2. Type in 'java -cp bin clubSimulation.ClubSimulation noClubgoers numxGridCells numyGridCells clubLimit' to run a custom sim or 'jave -cp bin clubSimulation.ClubSimulation' to run default
3. Hit 'Enter'