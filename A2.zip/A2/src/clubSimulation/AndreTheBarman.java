package clubSimulation;

import java.util.Random;

public class AndreTheBarman extends Thread {
    public  PeopleLocation barpersonLocation; //andres enter loc
    private GridBlock currentBlock; //andre current block
    private boolean inRoom;     //is andre in room
    public static ClubGrid club;    //the club
    private int speed;  //andre speed
    private Random rand;

    //constructor
    AndreTheBarman(PeopleLocation gps, int speed, ClubGrid club) {
        this.barpersonLocation = gps;
        inRoom = false;
        this.speed = speed;
        this.rand = new Random();
        this.club = club;
    }
    //andre enterclub method
    public void andreEnterClub() throws InterruptedException {
		currentBlock = Clubgoer.club.andreEnterClub(barpersonLocation);  //enter through entrance
		inRoom=true;
		System.out.println("Andre entered club at position: " + currentBlock.getX()  + " " +currentBlock.getY() );
		sleep(speed/2);  //wait a bit at door
	}
    //andre moves to the bar from the entrance
    private void andreHeadToBar() throws InterruptedException {
		int x_mv= rand.nextInt(3)-1;	//	-1,0 or 1
		int y_mv= Integer.signum(Clubgoer.club.getBar_y()-currentBlock.getY());//-1,0 or 1
		currentBlock=Clubgoer.club.moveAndre(currentBlock,x_mv,y_mv,barpersonLocation); //head toward bar
		sleep(speed/2);  //wait a bit
	}
    //andre serving drink
    public void serveDrink() throws InterruptedException{
        synchronized(Clubgoer.serving){
            Clubgoer.serving.notify();  //wakes up the thread that has been served
        }      
        sleep(speed/2);
    }
    //andre moving left and right at the bar
    public void move() throws InterruptedException{
        int x_mv;
        do {
            x_mv = rand.nextInt(3) - 1;  // -1, 0, or 1
        } while (x_mv == 0); // keep generating until a non-zero movement is achieved
		currentBlock=Clubgoer.club.moveAndre(currentBlock,x_mv,0,barpersonLocation); //head toward bar
        System.out.println("Andre moved across the bar to position: " + currentBlock.getX()  + " " +currentBlock.getY() );
		sleep(speed/2);  //wait a bit
    }
    //checks if pause is pressed
    private void checkPause() throws InterruptedException {
		synchronized(ClubSimulation.pause) {
			while (ClubSimulation.pause.get()) {
				ClubSimulation.pause.wait();
			}
		}
    }
    //checks if simulation started
    private void startSim() throws InterruptedException {
        Clubgoer.startLatch.await(); 	
    }
    //andre thread run process
    public void run() {
        try{
            startSim();
            checkPause();
            barpersonLocation.setArrived();
			System.out.println("Andre has arrived at club"); //output for checking
			checkPause(); //check whether have been asked to Clubgoer.serving
			andreEnterClub();
            checkPause();
            andreHeadToBar();

            while (inRoom) {
                checkPause();
                move();
                checkPause();
                //if andre is in front of a patron, he will serve a drink
                if(ClubSimulation.clubGrid.whichBlock(currentBlock.getX(),currentBlock.getY()-1).occupied()) {
                    serveDrink();
                }
                checkPause();
            }
        } catch (InterruptedException e) {}
    }
}