
//Grid for the club

package clubSimulation;

import java.util.concurrent.atomic.AtomicBoolean;

//This class represents the club as a grid of GridBlocks
public class ClubGrid {
	private GridBlock [][] Blocks;
	private final int x;
	private final int y;
	public  final int bar_y;
	
	private GridBlock exit;
	private GridBlock entrance; //hard coded entrance
	private GridBlock andreEntrance; //andre's hard coded entrance
	private final static int minX =5;//minimum x dimension
	private final static int minY =5;//minimum y dimension
	
	private PeopleCounter counter;
	public static AtomicBoolean entranceOccupied = new AtomicBoolean(false);
	private static Object movementLock = new Object();	// to ensure liveness
	
	ClubGrid(int x, int y, int [] exitBlocks,PeopleCounter c) throws InterruptedException {
		if (x<minX) x=minX; //minimum x
		if (y<minY) y=minY; //minimum x
		this.x=x;
		this.y=y;
		this.bar_y=y-3;
		Blocks = new GridBlock[x][y];
		this.initGrid(exitBlocks);
		entrance=Blocks[getMaxX()/2][0];
		andreEntrance = Blocks[getMaxX()/2][getMaxX()-1];
		counter=c;
		}
	
	//initialise the grsi, creating all the GridBlocks
	private  void initGrid(int []exitBlocks) throws InterruptedException {
		for (int i=0;i<x;i++) {
			for (int j=0;j<y;j++) {
				boolean exit_block=false;
				boolean bar=false;
				boolean dance_block=false;
				if ((i==exitBlocks[0])&&(j==exitBlocks[1])) {exit_block=true;}
				else if (j>=(y-3)) bar=true; 
				else if ((i>x/2) && (j>3) &&(j< (y-5))) dance_block=true;
				//bar is hardcoded two rows before  the end of the club
				Blocks[i][j]=new GridBlock(i,j,exit_block,bar,dance_block);
				if (exit_block) {this.exit = Blocks[i][j];}
			}
		}
	}
	
		public  int getMaxX() {
		return x;
	}
	
		public int getMaxY() {
		return y;
	}

	public GridBlock whereEntrance() { 
		return entrance;
	}

	// where is andre's entrance to the club
	public GridBlock whereAndreEntrance() {
		return andreEntrance;
	}

	//checks if the current block is the entrance
	public boolean isEntrance(GridBlock currentBlock) {
		return currentBlock.getX() == entrance.getX() && currentBlock.getY() == entrance.getY();
	}

	public  boolean inGrid(int i, int j) {
		if ((i>=x) || (j>=y) ||(i<0) || (j<0)) 
			return false;
		return true;
	}
	
	public  boolean inPatronArea(int i, int j) {
		if ((i>=x) || (j>bar_y) ||(i<0) || (j<0)) 
			return false;
		return true;
	}

	//checks that the area is a bar for andre to walk
	public boolean inBarArea(int i, int j ) {
		if ((i>=x) || (j<bar_y +1) || (i<0) || (j>y))
			return false;
		return true;
	}
	
	public GridBlock enterClub(PeopleLocation myLocation) throws InterruptedException  {
		counter.personArrived(); //add to counter of people waiting 
		synchronized(entrance) {	//synchronised so thread waits on entrance if needed and so thread with lock can exit before current thread enters
			while (counter.overCapacity() || !entrance.get(myLocation.getID())) { //while overcapity or entrance occupied
				entrance.wait();	//wait on entrance
			}
			counter.personEntered(); //add to counter
		}
		myLocation.setLocation(entrance);
		myLocation.setInRoom(true);
		return entrance;
	}
	
	//andre enter club
	public synchronized GridBlock andreEnterClub(PeopleLocation andreLocation) throws InterruptedException {
		andreEntrance.get(andreLocation.getID());
		andreLocation.setLocation(andreEntrance);
		andreLocation.setInRoom(true);
		return andreEntrance;
	}
	
	public GridBlock move(GridBlock currentBlock,int step_x, int step_y,PeopleLocation myLocation) throws InterruptedException {  //try to move in 
		synchronized(movementLock) {	//to ensure liveness
			int c_x= currentBlock.getX();
			int c_y= currentBlock.getY();
			
			int new_x = c_x+step_x; //new block x coordinates
			int new_y = c_y+step_y; // new block y  coordinates
			
			//restrict i an j to grid
			if (!inPatronArea(new_x,new_y)) {
				//Invalid move to outside  - ignore
				return currentBlock;
			}

			if ((new_x==currentBlock.getX())&&(new_y==currentBlock.getY())) //not actually moving
				return currentBlock;
			
			GridBlock newBlock = Blocks[new_x][new_y];
			
			if (!newBlock.get(myLocation.getID())) return currentBlock; //stay where you are
			
			currentBlock.release(); //must release current block
			myLocation.setLocation(newBlock);

			synchronized(entrance) {
				if(isEntrance(currentBlock) && !counter.overCapacity()) { //moving off entrances but club not full
					entrance.notify();	//notify any waiting thread
				}
			}
			return newBlock;
		}
		
	} 
	//method andre uses to move across the bar
	public GridBlock moveAndre(GridBlock currentBlock,int step_x, int step_y,PeopleLocation myLocation) throws InterruptedException {  //try to move in 
		synchronized(movementLock) {
			int c_x= currentBlock.getX();
			int c_y= currentBlock.getY();
			
			int new_x = c_x+step_x; //new block x coordinates
			int new_y = c_y+step_y; // new block y  coordinates

			if ((new_x==currentBlock.getX())&&(new_y==currentBlock.getY())) //not actually moving
				return currentBlock;

			//checks that the space andre moves is the bar
			if(inBarArea(new_x, new_y)) {
				GridBlock newBlock = Blocks[new_x][new_y];
				if (!newBlock.get(myLocation.getID())) return currentBlock; //stay where you are
				currentBlock.release(); //must release current block
				myLocation.setLocation(newBlock);
				return newBlock;
			}
			return currentBlock;
		}
	}

	public void leaveClub(GridBlock currentBlock,PeopleLocation myLocation)   {
		if(counter.overCapacity()) {	//if club full, notify threads waiting after leaving
			//synchronised so thread can leave before other ones enter
			synchronized(entrance) {	// removes the illegalstatemonitorexception
				currentBlock.release();
				counter.personLeft(); //add to counter
				myLocation.setInRoom(false);
				entrance.notify();
			}	
		}
		else {
			currentBlock.release();
			counter.personLeft();
			myLocation.setInRoom(false);
		}	
	}

	public GridBlock getExit() {
		return exit;
	}

	public GridBlock whichBlock(int xPos, int yPos) {
		if (inGrid(xPos,yPos)) {
			return Blocks[xPos][yPos];
		}
		System.out.println("block " + xPos + " " +yPos + "  not found");
		return null;
	}
	
	public void setExit(GridBlock exit) {
		this.exit = exit;
	}

	public int getBar_y() {
		return bar_y;
	}

}


	

	

